#' mypackage
#'
#' Contains 5 functions to use in my labs
#'
#' @doctype package
#'
#' @author Kyle Murphey \email{kyle.r.murphey@ou.edu}
#'
#' @name mypackage
NULL
